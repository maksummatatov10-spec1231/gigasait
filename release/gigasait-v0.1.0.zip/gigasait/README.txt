GIGASAIT v0.1.0
==============
Как открыть: распакуй архив и открой файл gigasait/index.html в браузере (двойной клик).
Разделы: index.html (главное меню) -> marketplace/ (маркетплейс), games/, community/.
Сайт работает без сервера — только HTML/CSS/JS, данные хранятся в localStorage браузера.
